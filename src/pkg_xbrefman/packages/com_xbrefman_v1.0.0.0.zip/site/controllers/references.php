<?php 
/*******
 * @package xbRefMan Component
 * @version 0.7.0 12th March 2022
 * @filesource site/controllers/references.php
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2022
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/

defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\CMS\Factory;

class XbrefmanControllerReferences extends JControllerForm {
    
//     function article() {
//         $jip =  Factory::getApplication()->input;
//         $id =  $jip->get('id');
//         $link = 'index.php?option=com_contents&view=article&id='.$id;
//         $this->setRedirect($link);
        
//     }

}
