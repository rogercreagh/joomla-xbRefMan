<?php
/*******
 * @package xbRefMan Component
 * @version 0.7.0 12th March 2022
 * @filesource site/controller.php
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2022
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/

defined( '_JEXEC' ) or die( 'Restricted access' );

class XbrefmanController extends JControllerLegacy {
    
    public function display ($cachable = false, $urlparms = false){        
        return parent::display();
    }
    
}
